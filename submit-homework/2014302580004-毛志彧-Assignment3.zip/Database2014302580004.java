import java.io.*;
import java.sql.*;
public class Database2014302580004 
{
public void Update(String input) throws ClassNotFoundException, SQLException, IOException
{
	
		String myconnection="jdbc:sqlserver://WWW-40CF488624B\\LPF:1433;"+"databaseName=Teachers;userName=mzy;password=123456";
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		Connection connection=DriverManager.getConnection(myconnection);
		Statement st=connection.createStatement();
		FileInputStream filein=new FileInputStream(input);
		InputStreamReader inputreader=new InputStreamReader(filein);
		BufferedReader reader=new BufferedReader(inputreader);
		String temp=reader.readLine();
		while(temp!=null)
		{
			String mzy[]=temp.split(",");
			String Updatesql="insert into Teachers value('"+mzy[0]+","+mzy[1]+","+mzy[2]+"'}";
			st.addBatch(Updatesql);
			temp=reader.readLine();
			st.execute(Updatesql);
		}
		reader.close();
		System.out.println("�ļ���ȡ���");
		
	
}
}
