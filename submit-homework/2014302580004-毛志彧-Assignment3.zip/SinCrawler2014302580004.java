import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class SinCrawler2014302580004 
{
private String IndexURL="http://users.sgg.whu.edu.cn/";
private File SingleThread=new File("SingleThread.txt");
private String[] personalURL=new String[5];
private String url1,url2,url3,url4,url5;
public SinCrawler2014302580004()
{
	
}

public void getAllURL () throws IOException//��ȡ������ҳ��ַ
{
	File temp=new File("SingleIndex.html");
	HttpRequest response=HttpRequest.get(IndexURL);
	response.receive(temp);
	Document doc=Jsoup.parse(temp, "UTF-8");
	Elements trs=doc.getElementsByTag("tr");
	Elements as=trs.select("a");
	for(int i=4;i<9;i++){personalURL[i-4]=as.get(i).attr("href");}
	url1=personalURL[0];
	url2=personalURL[1];
	url3=personalURL[2];
	url4=personalURL[3];
	url5=personalURL[4];
	
}

public void Crawl(String URL) throws IOException
{
		HttpRequest response=HttpRequest.get(URL);
		File temp=new File("SingleTemp.html");
		response.receive(temp);
		Document doc=Jsoup.parse(temp, "UTF-8");
		FileWriter ps=new FileWriter(SingleThread,true);
		//��ȡ����
		Elements name=doc.getElementsByClass("site-title");
		ps.write("������"+name.text()+"\n");
		
		Elements content=doc.getElementsByClass("entry-content").select("p");
		String contents=content.text();
		
		//��ȡ�绰
		String tel="\\d{3}\\D\\d{8}";
		Pattern a=Pattern.compile(tel);
		Matcher a1=a.matcher(contents);
		if(a1.find())
		{
			ps.write("�绰��"+a1.group(0)+"\n");
		}
		else
		{
			ps.write("�绰����"+"\n");
		}
		
		//��ȡ����
		String email="\\w+@(\\w+\\.){3}cn*";
		Pattern b=Pattern.compile(email);
		Matcher b1=b.matcher(contents);
		if(b1.find())
		{
			ps.write("���䣺"+b1.group(0)+"\n");
		}
		else
		{
			ps.write("���䣺��"+"\n");
		}
		
		//��ȡ���
		String introduce=content.get(1).text();
		ps.write("��飺"+introduce+"\n");
		ps.write("\n");
		ps.close();
}

public void SingleThread() throws IOException //ִ�е��߳���ȡ
{
	Crawl(url1);
	Crawl(url2);
	Crawl(url3);
	Crawl(url4);
	Crawl(url5);
}

}


