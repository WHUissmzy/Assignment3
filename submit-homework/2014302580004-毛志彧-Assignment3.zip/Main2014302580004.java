import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;

public class Main2014302580004 
{

	public static void main(String[] args) throws IOException
	{
		long singleStartTime=System.currentTimeMillis();
		SinCrawler2014302580004 mzy=new SinCrawler2014302580004();
		mzy.getAllURL();
		mzy.SingleThread();
		long singleEndTime=System.currentTimeMillis();
		System.out.println("���߳���������ʱ�䣺 "+(singleEndTime-singleStartTime)+"ms");
		
		long multipleStartTime=System.currentTimeMillis();
		MultiCrawler2014302580004 a1=new MultiCrawler2014302580004("http://kjyang.users.sgg.whu.edu.cn/");
		MultiCrawler2014302580004 a2=new MultiCrawler2014302580004("http://hjshi.users.sgg.whu.edu.cn/");
		MultiCrawler2014302580004 a3=new MultiCrawler2014302580004("http://xmcheng.users.sgg.whu.edu.cn/");
		MultiCrawler2014302580004 a4=new MultiCrawler2014302580004("http://ymqin.users.sgg.whu.edu.cn/");
		MultiCrawler2014302580004 a5=new MultiCrawler2014302580004("http://ychgao.users.sgg.whu.edu.cn/");
		a1.start();
		a2.start();
		a3.start();
		a4.start();
		a5.start();
		long multipleEndTime=System.currentTimeMillis();
		System.out.println("���߳���������ʱ�䣺 "+(multipleEndTime-multipleStartTime)+"ms");
		
	}

}
