import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.select.Elements;

public class MultiCrawler2014302580004 extends Thread
{
	private File MultipleThread=new File("MultipleThread.txt");
	private String URL;
	public MultiCrawler2014302580004(String url)
	{
		URL=url;
	}

	public void run()
	{
			HttpRequest response=HttpRequest.get(URL);
			File temp=new File("MultipleTemp.html");
			response.receive(temp);
			Document doc = null;
			try {
				doc = Jsoup.parse(temp, "UTF-8");
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			FileWriter ps = null;
			try {
				ps = new FileWriter(MultipleThread,true);
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			//��ȡ����
			Elements name=doc.getElementsByClass("site-title");
			try {
				ps.write("������"+name.text()+"\n");
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			
			Elements content=doc.getElementsByClass("entry-content").select("p");
			String contents=content.text();
			
			//��ȡ�绰
			String tel="\\d{3}\\D\\d{8}";
			Pattern a=Pattern.compile(tel);
			Matcher a1=a.matcher(contents);
			if(a1.find())
			{
				try {
					ps.write("�绰��"+a1.group(0)+"\n");
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			else
			{
				try {
					ps.write("�绰����"+"\n");
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			
			//��ȡ����
			String email="\\w+@(\\w+\\.){3}cn*";
			Pattern b=Pattern.compile(email);
			Matcher b1=b.matcher(contents);
			if(b1.find())
			{
				try {
					ps.write("���䣺"+b1.group(0)+"\n");
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			else
			{
				try {
					ps.write("���䣺��"+"\n");
				} catch (IOException e) {
					// TODO �Զ����ɵ� catch ��
					e.printStackTrace();
				}
			}
			
			//��ȡ���
			String introduce=content.get(1).text();
			try {
				ps.write("��飺"+introduce+"\n");
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			try {
				ps.write("\n");
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
			try {
				ps.close();
			} catch (IOException e) {
				// TODO �Զ����ɵ� catch ��
				e.printStackTrace();
			}
	}
	
}
